import pygame
from sys import exit

pygame.init()
screen = pygame.display.set_mode((1000, 600))
pygame.display.set_caption('Runner')
clock = pygame.time.Clock()
road_surface = pygame.image.load('graphics/Road.png').convert()
original_car_image = pygame.image.load('graphics/Porsche.png').convert_alpha()
car_image = pygame.transform.scale(original_car_image, (int(original_car_image.get_width() * 0.5), int(original_car_image.get_height() * 0.5)))

walking_frame_1 = pygame.image.load('graphics/walking.png').convert_alpha()
walking_frame_2 = pygame.image.load('graphics/walk.png').convert_alpha()
walking_frames = [walking_frame_1, walking_frame_2]

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = car_image
        self.rect = self.image.get_rect(midbottom=(100, 400))
        self.direction = 1

    def update(self):
        self.rect.x += self.direction * 2
        if self.rect.left <= 0:
            self.direction = 1
        elif self.rect.right >= screen.get_width():
            self.direction = -1

class Walker(pygame.sprite.Sprite):
    def __init__(self, initial_position):
        super().__init__()
        self.frames = walking_frames
        self.frame_index = 0
        self.image = self.frames[self.frame_index]
        self.rect = self.image.get_rect(midbottom=initial_position)
        self.speed = -2  

    def update(self):

        self.frame_index += 0.1
        if self.frame_index >= len(self.frames):
            self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]

        self.rect.x += self.speed
        
 
        if self.rect.right < 0:
            self.rect.left = screen.get_width()


player = pygame.sprite.GroupSingle()
player.add(Player())

walker_group = pygame.sprite.Group()

walker_group.add(Walker((screen.get_width(), 200)))

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    screen.blit(road_surface, (0, 0))
    player.update()
    player.draw(screen)
    walker_group.update()
    walker_group.draw(screen)
    pygame.display.update()
    clock.tick(60)
